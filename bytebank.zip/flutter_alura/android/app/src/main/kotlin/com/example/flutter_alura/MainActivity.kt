package com.example.flutter_alura

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
